import { produce } from "immer";
import { createMigrate } from "@sculptor/helpers";
import { ISettings } from "./types";

export const migrationManifest = createMigrate<ISettings>({});
