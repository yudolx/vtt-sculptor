// @ts-check
import webpack from "webpack";
import path from "path";
import { merge } from "webpack-merge";
import {
  config as commonConfig,
  SRC_DIR,
  DIST_DIR,
} from "./webpack.config.common.mjs";
import { __PLUGIN_ID__ } from "./define.mjs";

const rendererConfig = merge(
  commonConfig,
  /** @type {import('webpack').Configuration} */ ({
    entry: {
      renderer: path.resolve(SRC_DIR, "./renderer.tsx"),
    },
    optimization: {
      mergeDuplicateChunks: true,
    },
    output: {
      path: DIST_DIR,
      globalObject: "window",
      // library: {
      //   type: "window",
      //   name: JSON.parse(__PLUGIN_ID__),
      // },
    },
    target: "electron-renderer",
    plugins: [
      new webpack.container.ModuleFederationPlugin({
        name: JSON.parse(__PLUGIN_ID__),
        filename: "exposes.js",
        library: { type: "window", name: JSON.parse(__PLUGIN_ID__) },
        exposes: {
          "./App": "./src/renderer.tsx",
        },
        remotes: {
          host: `promise new Promise(resolve => {
            if (!window.host){
                        alert('plugin');
    const url = "plugins://host/file/host_exposes.js";
    const script = document.createElement('script');
    script.src = url;
    script.onload = () => resolve(window.host);
    document.head.appendChild(script);
    }
  })`,
        },
        shared: {
          react: {
            singleton: true,
            eager: true,
            requiredVersion: "^18.3.1",
          },
          "react-dom": {
            singleton: true,
            eager: true,
            requiredVersion: "^18.3.1",
          },
          "@mui/joy": { singleton: true, eager: true },
          "@tanstack/react-query": { singleton: true, eager: true },
          VideoContext: {
            singleton: true,
            eager: true,
          },
        },
      }),
    ],
  }),
);

const mainProcessConfig = merge(
  commonConfig,
  /** @type {import('webpack').Configuration} */ ({
    entry: {
      main: path.resolve(SRC_DIR, "./main.ts"),
    },
    output: {
      path: DIST_DIR,
      library: {
        type: "commonjs",
      },
    },
    target: "electron-main",
  }),
);

const preloadConfig = merge(
  commonConfig,
  /** @type {import('webpack').Configuration} */ ({
    entry: {
      preload: path.resolve(SRC_DIR, "./preload.ts"),
    },
    output: {
      path: DIST_DIR,
      library: {
        type: "commonjs",
      },
    },
    target: "electron-preload",
  }),
);

export default [rendererConfig, preloadConfig, mainProcessConfig];
