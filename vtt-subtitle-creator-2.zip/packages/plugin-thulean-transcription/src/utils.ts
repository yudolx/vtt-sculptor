let hostScriptLoadPromise: Promise<void> | null = null;

export const lazyHostLoad = async (modulePath: string) => {
  console.log("lazyHostLoad");
  await loadHostExposes();
  // @ts-expect-error
  await __webpack_init_sharing__("default");

  const container = (window as any)["host"];
  if (!container.__initialized) {
    // @ts-expect-error
    await container.init(__webpack_share_scopes__.default);
    container.__initialized = true;
  }

  const factory = await container.get(modulePath);
  return factory();
};

const loadHostExposes = () => {
  if (hostScriptLoadPromise) {
    return hostScriptLoadPromise;
  } else {
    hostScriptLoadPromise = new Promise<void>((resolve) => {
      const scriptEl = document.createElement("script");
      scriptEl.src = "plugins://host/file/host_exposes.js";
      scriptEl.async = true;
      scriptEl.addEventListener("load", () => {
        resolve();
      });

      document.head.appendChild(scriptEl);
    });
  }
};
