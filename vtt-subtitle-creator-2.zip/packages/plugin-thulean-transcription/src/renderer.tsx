import React from "react";
// @ts-expect-error
import { VideoElContext } from "host/VideoContext";

console.log("plugin", VideoElContext);

export default function () {
  // @ts-expect-error
  const { videoEl } = React.useContext(VideoElContext);
  console.log("rendering", videoEl);
  return <div>Hello 11!</div>;
}
