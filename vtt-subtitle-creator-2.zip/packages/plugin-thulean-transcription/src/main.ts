export const pluginId = __PLUGIN_ID__;
export const pluginName = "Thulean transcription";
export const pluginDescription = "";
export const toolbarButtons = [
  {
    tag: "<br />",
    description: "New line",
  },
  {
    tag: ["<hft>", "</hft>"],
    description: "Hide from transcription",
  },
  {
    tag: ["<ol>", "</ol>"],
  },
  {
    tag: ["<ul>", "</ul>"],
  },
  {
    tag: ["<li>", "</li>"],
  },
];
export const settings = [{ type: "input", name: "screenshots_dir" }];
