const x = (string) => JSON.stringify(string);

export const __DEVELOPMENT__ = x(process.env.NODE_ENV === "development");
export const __PLUGIN_ID__ = x("thulean_transcription");
